Place wedding photos here (jpg/png) and reference them in style.css masonry tiles
